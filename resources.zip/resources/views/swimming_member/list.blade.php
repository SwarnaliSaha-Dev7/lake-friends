@extends('base.app')

@section('title', $title)
@section('page_title', $page_title)

@section('content')
    <div class="row">
        <div class="col-12">
            <div class="member-list-part position-relative">
                <div class="d-flex align-items-center justify-content-between gap-2 mb-2 flex-wrap">
                    <h2 class="fs-5 common-heading mb-md-0 fw-semibold">Swimming Member list</h2>
                    <div class="d-flex gap-2">
                        <div class="d-flex justify-content-end">
                            <select id="statusFilter"
                                class="form-select form-select-sm w-auto fs-6 rounded-2 ps-3 shadow-none">
                                <option value="" selected disabled hidden>Status filter</option>
                                <option value="" hidden disabled selected>All</option>
                                <option value="Active">Active</option>
                                <option value="Inactive">Pending</option>
                                <option value="Blocked">Rejected</option>
                            </select>
                        </div>
                        <button class="btn btn-info" data-bs-toggle="modal" id="addSwimmingMemberBtn" data-bs-target="#addswimmingmember">+ Add swimming member</button>
                    </div>
                </div>
                <div class="table-responsive">
                    <table class="table rounded-3 overflow-hidden clubmemberlist2" cellspacing="0"
                        width="100%">
                        <thead>
                            <tr>
                                <th class="text-white fw-medium align-middle text-nowrap">Sl No</th>
                                <th class="text-white fw-medium align-middle text-nowrap">Name</th>
                                <th class="text-white fw-medium align-middle text-nowrap">Phone</th>
                                <th class="text-white fw-medium align-middle text-nowrap">Card Number
                                </th>
                                <th class="text-white fw-medium align-middle text-nowrap">Wallet</th>
                                <th class="text-white fw-medium align-middle text-nowrap">Exp. Date</th>
                                <th class="text-white fw-medium align-middle text-nowrap">Approve by
                                </th>
                                <th class="text-white fw-medium align-middle text-nowrap">Status</th>
                                <th class="text-white fw-medium align-middle text-nowrap">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($members as $member)
                                <tr>
                                    <td class="text-nowrap">{{ $loop->iteration }}</td>
                                    <td class="text-nowrap">{{$member->name}}</td>
                                    <td class="text-nowrap">{{$member->phone}}</td>
                                    <td class="text-nowrap">{{ $member->cardDetails?->card_no ?? '-' }}</td>
                                    <td class="text-nowrap">₹ {{$member->walletDetails?->current_balance ?? 0}}</td>
                                    <td class="text-nowrap">{{ isset($member->purchaseHistory[0]) ? \Carbon\Carbon::parse($member->purchaseHistory[0]->expiry_date)->format('d/m/Y') : 'N/A' }}</td>
                                    <td class="text-nowrap">
                                        {{ ucwords($member->latestApproval?->checker?->name ?? '-') }}
                                    </td>
                                    @if ($member->status == 'active')
                                        <td class="text-success text-nowrap">Active</td>
                                    @elseif ($member->status == 'pending')
                                        <td class="text-warning text-nowrap">Pending</td>
                                    @elseif ($member->status == 'rejected')
                                        <td class="text-danger text-nowrap">Rejected</td>
                                    @endif

                                    <td class="text-nowrap">
                                        <button class="border-0 bg-light p-1 rounded-3 lh-1 action-btn viewProfileBtn"
                                            title="View Profile" data-id="{{$member->id}}" id=""><small><i
                                                    class="fa-regular fa-eye"></i></small></button>
                                        <button class="border-0 bg-light p-1 rounded-3 lh-1 action-btn membershipPlanBtn"
                                            title="Membership Plan" data-id="{{$member->id}}"><small><i
                                                    class="fa-sharp fa-clock-rotate-left"></i></small></button>
                                        <button class="border-0 bg-light p-1 rounded-3 lh-1 action-btn walletRechargeBtn"
                                            title="Wallet Recharge" data-id="{{$member->id}}"><small><i
                                                    class="fa-solid fa-wallet"></i></small></button>
                                        <button class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"
                                            data-bs-toggle="modal" data-bs-target="#planrenewal"
                                            title="Plan Renewal" data-id="{{$member->id}}"><small><i
                                                    class="fa-solid fa-rotate-right"></i></small></button>
                                        <button class="border-0 bg-light p-1 rounded-3 lh-1 action-btn memberEditBtn"
                                            title="Edit" data-id="{{$member->id}}"><small><i
                                                    class="fa-solid fa-pen-to-square"></i></small></button>
                                        <button
                                            class="border-0 bg-light p-1 rounded-3 lh-1 action-btn delete-row memberDeleteBtn" data-id="{{$member->id}}"
                                            title="Delete" data-bs-toggle="modal" data-bs-target="#deleteConfirmModal"><small><i
                                                    class="fa-solid fa-trash"></i></small></button>

                                    </td>
                                </tr>
                            @endforeach
                            {{-- <tr>
                                <td class="text-nowrap">Soumen Das</td>
                                <td class="text-nowrap">+91 9025 321423</td>
                                <td class="text-nowrap">12345abcd</td>
                                <td class="text-nowrap">₹ 2000</td>
                                <td class="text-nowrap">12/31/2026</td>
                                <td class="text-nowrap">Admin</td>
                                <td class="text-success text-nowrap">Active</td>
                                <td class="text-nowrap">
                                    <button class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"
                                        data-bs-toggle="modal" data-bs-target="#viewprofile"
                                        title="View Profile"><small><i
                                                class="fa-regular fa-eye"></i></small></button>
                                    <button class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"
                                        data-bs-toggle="modal" data-bs-target="#membershipplan"
                                        title="Membership Plan"><small><i
                                                class="fa-sharp fa-clock-rotate-left"></i></small></button>
                                    <button class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"
                                        data-bs-toggle="modal" data-bs-target="#walletrecharge"
                                        title="Wallet Recharge"><small><i
                                                class="fa-solid fa-wallet"></i></small></button>
                                    <button class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"
                                        data-bs-toggle="modal" data-bs-target="#planrenewal"
                                        title="Plan Renewal"><small><i
                                                class="fa-solid fa-rotate-right"></i></small></button>
                                    <button class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"
                                        title="Edit"><small><i
                                                class="fa-solid fa-pen-to-square"></i></small></button>
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn delete-row"
                                        title="Delete"><small><i
                                                class="fa-solid fa-trash"></i></small></button>

                                </td>
                            </tr>
                            <tr>
                                <td class="text-nowrap">Soumen Das</td>
                                <td class="text-nowrap">+91 9025 321423</td>
                                <td class="text-nowrap">12345abcd</td>
                                <td class="text-nowrap">₹ 2000</td>
                                <td class="text-nowrap">12/31/2026</td>
                                <td class="text-nowrap">Admin</td>
                                <td class="text-danger text-nowrap">Blocked</td>
                                <td class="text-nowrap">
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-regular fa-eye"></i></small></button>
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-sharp fa-clock-rotate-left"></i></small></button>
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-solid fa-wallet"></i></small></button>
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-solid fa-rotate-right"></i></small></button>
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-solid fa-pen-to-square"></i></small></button>
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-solid fa-trash"></i></small></button>

                                </td>
                            </tr>
                            <tr>
                                <td class="text-nowrap">Soumen Das</td>
                                <td class="text-nowrap">+91 9025 321423</td>
                                <td class="text-nowrap">12345abcd</td>
                                <td class="text-nowrap">₹ 2000</td>
                                <td class="text-nowrap">12/31/2026</td>
                                <td class="text-nowrap">Admin</td>
                                <td class="text-secondary text-nowrap">Inactive</td>
                                <td class="text-nowrap">
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-regular fa-eye"></i></small></button>
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-sharp fa-clock-rotate-left"></i></small></button>
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-solid fa-wallet"></i></small></button>
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-solid fa-rotate-right"></i></small></button>
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-solid fa-pen-to-square"></i></small></button>
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-solid fa-trash"></i></small></button>

                                </td>
                            </tr>
                            <tr>
                                <td class="text-nowrap">Soumen Das</td>
                                <td class="text-nowrap">+91 9025 321423</td>
                                <td class="text-nowrap">12345abcd</td>
                                <td class="text-nowrap">₹ 2000</td>
                                <td class="text-nowrap">12/31/2026</td>
                                <td class="text-nowrap">Admin</td>
                                <td class="text-success text-nowrap">Active</td>
                                <td class="text-nowrap">
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-regular fa-eye"></i></small></button>
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-sharp fa-clock-rotate-left"></i></small></button>
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-solid fa-wallet"></i></small></button>
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-solid fa-rotate-right"></i></small></button>
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-solid fa-pen-to-square"></i></small></button>
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-solid fa-trash"></i></small></button>

                                </td>
                            </tr>
                            <tr>
                                <td class="text-nowrap">Soumen Das</td>
                                <td class="text-nowrap">+91 9025 321423</td>
                                <td class="text-nowrap">12345abcd</td>
                                <td class="text-nowrap">₹ 2000</td>
                                <td class="text-nowrap">12/31/2026</td>
                                <td class="text-nowrap">Admin</td>
                                <td class="text-secondary text-nowrap">Inactive</td>
                                <td class="text-nowrap">
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-regular fa-eye"></i></small></button>
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-sharp fa-clock-rotate-left"></i></small></button>
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-solid fa-wallet"></i></small></button>
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-solid fa-rotate-right"></i></small></button>
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-solid fa-pen-to-square"></i></small></button>
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-solid fa-trash"></i></small></button>

                                </td>
                            </tr>
                            <tr>
                                <td class="text-nowrap">Soumen Das</td>
                                <td class="text-nowrap">+91 9025 321423</td>
                                <td class="text-nowrap">12345abcd</td>
                                <td class="text-nowrap">₹ 2000</td>
                                <td class="text-nowrap">12/31/2026</td>
                                <td class="text-nowrap">Admin</td>
                                <td class="text-secondary text-nowrap">Inactive</td>
                                <td class="text-nowrap">
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-regular fa-eye"></i></small></button>
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-sharp fa-clock-rotate-left"></i></small></button>
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-solid fa-wallet"></i></small></button>
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-solid fa-rotate-right"></i></small></button>
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-solid fa-pen-to-square"></i></small></button>
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-solid fa-trash"></i></small></button>

                                </td>
                            </tr>
                            <tr>
                                <td class="text-nowrap">Soumen Das</td>
                                <td class="text-nowrap">+91 9025 321423</td>
                                <td class="text-nowrap">12345abcd</td>
                                <td class="text-nowrap">₹ 2000</td>
                                <td class="text-nowrap">12/31/2026</td>
                                <td class="text-nowrap">Admin</td>
                                <td class="text-success text-nowrap">Active</td>
                                <td class="text-nowrap">
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-regular fa-eye"></i></small></button>
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-sharp fa-clock-rotate-left"></i></small></button>
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-solid fa-wallet"></i></small></button>
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-solid fa-rotate-right"></i></small></button>
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-solid fa-pen-to-square"></i></small></button>
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-solid fa-trash"></i></small></button>

                                </td>
                            </tr>
                            <tr>
                                <td class="text-nowrap">Soumen Das</td>
                                <td class="text-nowrap">+91 9025 321423</td>
                                <td class="text-nowrap">12345abcd</td>
                                <td class="text-nowrap">₹ 2000</td>
                                <td class="text-nowrap">12/31/2026</td>
                                <td class="text-nowrap">Admin</td>
                                <td class="text-success text-nowrap">Active</td>
                                <td class="text-nowrap">
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-regular fa-eye"></i></small></button>
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-sharp fa-clock-rotate-left"></i></small></button>
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-solid fa-wallet"></i></small></button>
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-solid fa-rotate-right"></i></small></button>
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-solid fa-pen-to-square"></i></small></button>
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-solid fa-trash"></i></small></button>

                                </td>
                            </tr>
                            <tr>
                                <td class="text-nowrap">Soumen Dass</td>
                                <td class="text-nowrap">+91 9025 321423</td>
                                <td class="text-nowrap">12345abcd</td>
                                <td class="text-nowrap">₹ 2000</td>
                                <td class="text-nowrap">12/31/2026</td>
                                <td class="text-nowrap">Admin</td>
                                <td class="text-success text-nowrap">Active</td>
                                <td class="text-nowrap">
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-regular fa-eye"></i></small></button>
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-sharp fa-clock-rotate-left"></i></small></button>
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-solid fa-wallet"></i></small></button>
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-solid fa-rotate-right"></i></small></button>
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-solid fa-pen-to-square"></i></small></button>
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-solid fa-trash"></i></small></button>

                                </td>
                            </tr>
                            <tr>
                                <td class="text-nowrap">Soumen Dasss</td>
                                <td class="text-nowrap">+91 9025 321423</td>
                                <td class="text-nowrap">12345abcd</td>
                                <td class="text-nowrap">₹ 2000</td>
                                <td class="text-nowrap">12/31/2026</td>
                                <td class="text-nowrap">Admin</td>
                                <td class="text-danger text-nowrap">Blocked</td>
                                <td class="text-nowrap">
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-regular fa-eye"></i></small></button>
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-sharp fa-clock-rotate-left"></i></small></button>
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-solid fa-wallet"></i></small></button>
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-solid fa-rotate-right"></i></small></button>
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-solid fa-pen-to-square"></i></small></button>
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-solid fa-trash"></i></small></button>

                                </td>
                            </tr>
                            <tr>
                                <td class="text-nowrap">Ssoumen Das</td>
                                <td class="text-nowrap">+91 9025 321423</td>
                                <td class="text-nowrap">12345abcd</td>
                                <td class="text-nowrap">₹ 2000</td>
                                <td class="text-nowrap">12/31/2026</td>
                                <td class="text-nowrap">Admin</td>
                                <td class="text-danger text-nowrap">Blocked</td>
                                <td class="text-nowrap">
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-regular fa-eye"></i></small></button>
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-sharp fa-clock-rotate-left"></i></small></button>
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-solid fa-wallet"></i></small></button>
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-solid fa-rotate-right"></i></small></button>
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-solid fa-pen-to-square"></i></small></button>
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-solid fa-trash"></i></small></button>

                                </td>
                            </tr>
                            <tr>
                                <td class="text-nowrap">Sssoumen Das</td>
                                <td class="text-nowrap">+91 9025 321423</td>
                                <td class="text-nowrap">12345abcd</td>
                                <td class="text-nowrap">₹ 2000</td>
                                <td class="text-nowrap">12/31/2026</td>
                                <td class="text-nowrap">Admin</td>
                                <td class="text-danger text-nowrap">Blocked</td>
                                <td class="text-nowrap">
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-regular fa-eye"></i></small></button>
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-sharp fa-clock-rotate-left"></i></small></button>
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-solid fa-wallet"></i></small></button>
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-solid fa-rotate-right"></i></small></button>
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-solid fa-pen-to-square"></i></small></button>
                                    <button
                                        class="border-0 bg-light p-1 rounded-3 lh-1 action-btn"><small><i
                                                class="fa-solid fa-trash"></i></small></button>

                                </td>
                            </tr> --}}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
@endsection

@section('modalComponent')
    <!-- add Club Member Modal start -->
    <div class="modal fade" id="addswimmingmember" tabindex="-1" aria-labelledby="addswimmingmemberModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header border-0">
                    <h2 class="modal-title fs-5 fw-semibold" id="addswimmingmemberModalLabel">Swimming-only membership
                    </h2>
                    <button type="button" class="btn-close bg-transparent fs-5 lh-1" data-bs-dismiss="modal"
                        aria-label="Close"><i class="fa-regular fa-circle-xmark"></i></button>
                </div>
                <div class="modal-body">
                    <form action="" id="swimmingMemberForm">
                        @csrf
                        <div class="row">
                            <div class="col-lg-12">
                                <label for="" class="form-label fw-semibold text-dark mb-3"><span
                                        class="text-info rounded-3 label-icon p-1 d-inline-flex align-items-center justify-content-center me-2"><i
                                            class="fa-regular fa-user"></i></span> Personal Details</label>
                                <div class="row">
                                    <div class="col-md-6 col-xl-3">
                                        <div class="form-part mb-3">
                                            <label for="" class="form-label w-100 mb-1 w-100"><small>Full Name</small></label>
                                            <input type="text" class="form-control py-2 shadow-none" name="swim_name" id=""
                                                placeholder="Full Name" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-xl-3">
                                        <div class="form-part mb-3">
                                            <label for="" class="form-label w-100 mb-1 w-100"><small>Email</small></label>
                                            <input type="email" class="form-control py-2 shadow-none" name="swim_email" id=""
                                                placeholder="Email" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-xl-3">
                                        <div class="form-part mb-3">
                                            <label for="" class="form-label w-100 mb-1 w-100"><small>Phone</small></label>
                                            <input type="tel" class="form-control py-2 shadow-none phone-input" name="swim_phone" id=""
                                                placeholder="Phone" required>
                                            <span class="error-div text-danger"></span>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-xl-3">
                                        <div class="form-part mb-3">
                                            <label for="" class="form-label w-100 mb-1 w-100"><small>Address</small></label>
                                            {{-- <input type="text" class="form-control py-2 shadow-none" name="swim_address" id=""
                                                placeholder="Address" required> --}}
                                            <textarea class="form-control py-2 shadow-none" id="" name="swim_address" rows="3"
                                                placeholder="Address" required></textarea>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-xl-3">
                                        <div class="form-part mb-3">
                                            <label for="" class="form-label w-100 mb-1 w-100"><small>Police Station</small></label>
                                            <input type="text" class="form-control py-2 shadow-none" name="swim_police_station" id="swim_police_station"
                                                placeholder="Police Station" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-xl-3">
                                        <div class="form-part mb-3">
                                            <label for="" class="form-label w-100 mb-1 w-100"><small>Age</small></label>
                                            <input type="number" class="form-control py-2 shadow-none" name="swim_age" id=""
                                                placeholder="Age" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-xl-3">
                                        <div class="form-part mb-3">
                                            <label for="" class="form-label w-100 mb-1 w-100"><small>Sex</small></label>
                                            <select name="swim_sex" id="" class="form-select py-2 shadow-none" required>
                                                <option value="" hidden disabled selected>Sex</option>
                                                <option value="male">Male</option>
                                                <option value="female">Female</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-xl-3">
                                        <div class="form-part mb-3">
                                            <label for="" class="form-label w-100 mb-1 w-100"><small>Height</small></label>
                                            <input type="number" class="form-control py-2 shadow-none" name="swim_height" id=""
                                                placeholder="Height" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-xl-3">
                                        <div class="form-part mb-3">
                                            <label for="" class="form-label w-100 mb-1 w-100"><small>Weight</small></label>
                                            <input type="number" class="form-control py-2 shadow-none" name="swim_weight" id=""
                                                placeholder="Weight" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-xl-4">
                                        <div class="form-part mb-3">
                                            <label for="" class="form-label w-100 mb-1 w-100"><small>Pulse Rate</small></label>
                                            <input type="number" class="form-control py-2 shadow-none" name="swim_pulse_rate" id=""
                                                placeholder="Pulse Rate" required>
                                        </div>
                                    </div>
                                    {{-- <div class="col-md-6 col-xl-4">
                                        <div class="form-part mb-3">
                                            <select name="" id="" class="form-select py-2 shadow-none">
                                                <option value="" hidden disabled selected>Batch</option>
                                                <option value="" hidden disabled selected>Batch1</option>
                                                <option value="" hidden disabled selected>Batch2</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-xl-4">
                                        <div class="form-part mb-3">
                                            <select name="" id="" class="form-select py-2 shadow-none">
                                                <option value="" hidden disabled selected>Vaccination</option>
                                                <option value="" hidden disabled selected>vaccination1</option>
                                            </select>
                                        </div>
                                    </div> --}}
                                    <div class="col-md-6 col-xl-4">
                                        <div class="form-part mb-3">
                                            <label for="" class="form-label w-100 mb-1 w-100"><small>Batch</small></label>
                                            <input type="text" class="form-control py-2 shadow-none" name="swim_batch" id=""
                                                placeholder="Batch" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-xl-4">
                                        <div class="form-part mb-3">
                                            <label for="" class="form-label w-100 mb-1 w-100"><small>Vaccination</small></label>
                                            <input type="text" class="form-control py-2 shadow-none" name="swim_vaccination" id=""
                                                placeholder="Vaccination" required>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-check mb-3">
                                            <input class="form-check-input" type="checkbox" value="" name="swim_i_agree" id="flexCheck1" required>
                                            <label class="form-check-label" for="flexCheck1">
                                                <small>I have gone through the rules & Regulations overleaf and undertake to abide by the same at my risk and cost.</small>
                                            </label>
                                        </div>
                                    </div>

                                    <div class="col-lg-8">
                                        <div class="form-part mb-3">
                                            <label for="" class="form-label w-100"><small>I am not suffering
                                                    from</small></label>
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="checkbox" id="inlineCheckbox1"
                                                    value="occational_faint" name="swim_disease[]">
                                                <label class="form-check-label" for="inlineCheckbox1"><small>Any sudden
                                                        or
                                                        occasional faint</small></label>
                                            </div>
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="checkbox" id="inlineCheckbox2"
                                                    value="lung_heart_trouble" name="swim_disease[]">
                                                <label class="form-check-label" for="inlineCheckbox2"><small>Lung/Heart
                                                        trouble</small></label>
                                            </div>
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="checkbox" id="inlineCheckbox3"
                                                    value="skin_disease" name="swim_disease[]">
                                                <label class="form-check-label" for="inlineCheckbox3"><small>Skin
                                                        disease</small></label>
                                            </div>
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="checkbox" id="inlineCheckbox4"
                                                    value="other_disease" name="swim_disease[]">
                                                <label class="form-check-label" for="inlineCheckbox4"><small>Any other
                                                        disease</small></label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-part mb-3">
                                            <label for="" class="form-label w-100 mb-1 w-100"><small>Photo</small></label>
                                            <label class="file-upload-box position-relative text-center border rounded-3 w-100 p-2">
                                                <input type="file" class="file-input opacity-0 position-absolute start-0 w-100 profile-image" name="swim_image" accept=".jpg,.jpeg,.png" required>
                                                <div class="upload-content">
                                                    <i class="upload-icon"><i
                                                            class="fa-solid fa-arrow-up-from-bracket"></i></i>
                                                    <p class="upload-text mb-0">
                                                        Upload Passport size Image & Signature
                                                    </p>
                                                    <small class="text-muted">
                                                        Image format, PNG & JPEG, max file size 5MB
                                                    </small>
                                                </div>
                                            </label>
                                            <span class="error-div text-danger"></span>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <div class="col-lg-12">
                                <label for="" class="form-label fw-semibold text-dark my-3"><span
                                        class="text-info rounded-3 label-icon p-1 d-inline-flex align-items-center justify-content-center me-2"><i
                                            class="fa-regular fa-user"></i></span> Family Details</label>
                                <div class="row">
                                    <div class="col-lg-4">
                                        <div class="form-part mb-3">
                                            <label for="" class="form-label w-100 mb-1 w-100"><small>Father/Guardian’s Full Name</small></label>
                                            <input type="text" class="form-control py-2 shadow-none" id=""
                                                placeholder="Father/Guardian’s Full Name" name="swim_guardian_name" required>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-part mb-3">
                                            <label for="" class="form-label w-100 mb-1 w-100"><small>Father/Guardian’s Occupation</small></label>
                                            <input type="text" class="form-control py-2 shadow-none" id=""
                                                placeholder="Father/Guardian’s Occupation" name="swim_guardian_occupation" required>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-part mb-3">
                                            <label for="" class="form-label w-100 mb-1 w-100"><small>Father/Guardian’s Photo</small></label>
                                            <label class="file-upload-box position-relative text-center border rounded-3 w-100 p-2">
                                                <input type="file" class="file-input opacity-0 position-absolute start-0 w-100 profile-image" name="swim_guardian_image" accept=".jpg,.jpeg,.png" required>
                                                <div class="upload-content">
                                                    <i class="upload-icon"><i
                                                            class="fa-solid fa-arrow-up-from-bracket"></i></i>
                                                    <p class="upload-text mb-0">
                                                        Upload Passport size Image & Signature
                                                    </p>
                                                    <small class="text-muted">
                                                        Image format, PNG & JPEG, max file size 5MB
                                                    </small>
                                                </div>
                                            </label>
                                            <span class="error-div text-danger"></span>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <div class="col-lg-12">
                                <label for="" class="form-label fw-semibold text-dark my-3"><span
                                        class="text-info rounded-3 label-icon p-1 d-inline-flex align-items-center justify-content-center me-2"><i
                                            class="fa-regular fa-regular fa-credit-card"></i></span> Card
                                    Details</label>
                                <div class="row">
                                    <div class="col-12">
                                        <div class="form-part mb-3">
                                            <label for="" class="form-label w-100"><small>Plan type</small></label>

                                            @foreach ($membershipPlanList as $membershipPlan)
                                                <div class="form-check form-check-inline">
                                                    <input class="form-check-input plan-type" type="radio" name="swim_membership_plan_type"
                                                        id="inlineRadio{{$loop->iteration}}" value="{{$membershipPlan->id}}" required>
                                                    <label class="form-check-label"
                                                        for="inlineRadio{{$loop->iteration}}"><small>{{$membershipPlan->name}}</small></label>
                                                </div>
                                            @endforeach
                                            {{-- <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="radio" name="inlineRadioOptions2"
                                                    id="inlineRadio4" value="option1">
                                                <label class="form-check-label"
                                                    for="inlineRadio4"><small>Annual</small></label>
                                            </div>
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="radio" name="inlineRadioOptions2"
                                                    id="inlineRadio5" value="option2">
                                                <label class="form-check-label"
                                                    for="inlineRadio5"><small>Lifetime</small></label>
                                            </div>
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="radio" name="inlineRadioOptions2"
                                                    id="inlineRadio6" value="option3">
                                                <label class="form-check-label"
                                                    for="inlineRadio6"><small>Silver</small></label>
                                            </div> --}}
                                        </div>
                                    </div>
                                    {{-- <div class="col-md-6 col-xl-3">
                                        <div class="form-part mb-3">
                                            <select name="" id="" class="form-select py-2 shadow-none">
                                                <option value="" hidden disabled selected>Card Type</option>
                                                <option value="" hidden disabled selected>Card Type1</option>
                                                <option value="" hidden disabled selected>Card Type2</option>
                                            </select>
                                        </div>
                                    </div> --}}
                                    {{-- <div class="col-md-6 col-xl-4">
                                        <div class="form-part mb-3">
                                            <label for="" class="form-label w-100 mb-1 w-100"><small>Card No.</small></label>
                                            <input type="text" class="form-control py-2 shadow-none" name="swim_card_no" id=""
                                                placeholder="Card No.">
                                        </div>
                                    </div> --}}
                                    <div class="col-md-6 col-xl-4">
                                        <div class="form-part mb-3">
                                            <label for="" class="form-label w-100 mb-1 w-100"><small>Card No.</small></label>
                                            <select name="swim_card_id" id="" class="form-select py-2 shadow-none" required>
                                                <option value="" hidden disabled selected>Card No.</option>
                                                @foreach ($cards as $card)
                                                    <option value="{{$card->id}}">{{$card->card_no}}</option>
                                                @endforeach

                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-xl-4">
                                        <div class="form-part mb-3">
                                            <label for="" class="form-label w-100 mb-1 w-100"><small>Payment Mode</small></label>
                                            <input type="text" class="form-control py-2 shadow-none" id="" name="swim_payment_mode"
                                                placeholder="Payment Mode" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-xl-4">
                                        <div class="form-part mb-3">
                                            <label for="" class="form-label w-100 mb-1 w-100"><small>A/C Head</small></label>
                                            <input type="text" class="form-control py-2 shadow-none" id="" name="swim_ac_head"
                                                placeholder="A/C Head" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-xl-3">
                                        <div class="form-part mb-3">
                                            <label for="" class="form-label w-100 mb-1 w-100"><small>Taxable Amt. (Min 500)</small></label>
                                            <input type="number" class="form-control py-2 shadow-none" id="taxable_amount" name="swim_taxable_amt"
                                                placeholder="Taxable Amt. (Min 500)" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-xl-3">
                                        <div class="form-part mb-3">
                                            <label for="" class="form-label w-100 mb-1 w-100"><small>GST%</small></label>
                                            <input type="number" class="form-control py-2 shadow-none" id="gstPercentage" name="swim_gst_percent"
                                                placeholder="GST%" value="{{$gstPercentage}}" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-xl-3">
                                        <div class="form-part mb-3">
                                            <label for="" class="form-label w-100 mb-1 w-100"><small>GST Amt</small></label>
                                            <input type="text" class="form-control py-2 shadow-none" id="gstAmt" name="swim_gst_amt"
                                                placeholder="GST Amt" readonly required>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-xl-3">
                                        <div class="form-part mb-3">
                                            <label for="" class="form-label w-100 mb-1 w-100"><small>Receipt Amt</small></label>
                                            <input type="text" class="form-control py-2 shadow-none" id="receiptAmt" name="swim_receipt_amt"
                                                placeholder="Receipt Amt" readonly required>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-part mb-3">
                                            <label for="" class="form-label w-100 mb-1 w-100"><small>Bank Name</small></label>
                                            <select name="swim_bank_id" id="" class="form-select py-2 shadow-none" required>
                                                <option value="" hidden disabled selected>Bank Name</option>
                                                @foreach ($bankList as $bank)
                                                    <option value="{{$bank->id}}">{{$bank->name}}</option>
                                                @endforeach

                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-part mb-3">
                                            <label for="" class="form-label w-100 mb-1 w-100"><small>Remarks</small></label>
                                            <input type="text" class="form-control py-2 shadow-none" id="" name="swim_remarks"
                                                placeholder="Remarks" required>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <div class="text-end mod-footer mt-3">
                            <button type="button" class="btn btn-info fw-semibold"
                                data-bs-dismiss="modal">Cancel</button>
                            <input type="submit" class="btn btn-primary fw-semibold" value="Add Swimming-membership" id="swim_submit">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- add Club Member Modal end  -->

    <!-- edit Club Member Modal start -->
    <div class="modal fade" id="editswimmingmember" tabindex="-1" aria-labelledby="editswimmingmemberModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header border-0">
                    <h2 class="modal-title fs-5 fw-semibold" id="addswimmingmemberModalLabel">Edit membership
                    </h2>
                    <button type="button" class="btn-close bg-transparent fs-5 lh-1" data-bs-dismiss="modal"
                        aria-label="Close"><i class="fa-regular fa-circle-xmark"></i></button>
                </div>
                <div class="modal-body">
                    <form action="" id="swimmingMemberEditForm">
                        @csrf
                        <input type="hidden" name="member_id" value="" id="swim_member_id">
                        <div class="row">
                            <div class="col-lg-12">
                                <label for="" class="form-label fw-semibold text-dark mb-3"><span
                                        class="text-info rounded-3 label-icon p-1 d-inline-flex align-items-center justify-content-center me-2"><i
                                            class="fa-regular fa-user"></i></span> Personal Details</label>
                                <div class="row">
                                    <div class="col-md-6 col-xl-3">
                                        <div class="form-part mb-3">
                                            <label for="" class="form-label w-100 mb-1 w-100"><small>Full Name</small></label>
                                            <input type="text" class="form-control py-2 shadow-none" name="swim_name" id="swim_member_name"
                                                placeholder="Full Name" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-xl-3">
                                        <div class="form-part mb-3">
                                            <label for="" class="form-label w-100 mb-1 w-100"><small>Email</small></label>
                                            <input type="email" class="form-control py-2 shadow-none" name="swim_email" id="swim_member_email"
                                                placeholder="Email" required readonly>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-xl-3">
                                        <div class="form-part mb-3">
                                            <label for="" class="form-label w-100 mb-1 w-100"><small>Phone</small></label>
                                            <input type="tel" class="form-control py-2 shadow-none phone-input" name="swim_phone" id="swim_member_phone"
                                                placeholder="Phone" required>
                                            <span class="error-div text-danger"></span>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-xl-3">
                                        <div class="form-part mb-3">
                                            <label for="" class="form-label w-100 mb-1 w-100"><small>Address</small></label>

                                            <textarea class="form-control py-2 shadow-none" id="swim_member_address" name="swim_address" rows="3"
                                                placeholder="Address" required></textarea>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-xl-3">
                                        <div class="form-part mb-3">
                                            <label for="" class="form-label w-100 mb-1 w-100"><small>Police Station</small></label>
                                            <input type="text" class="form-control py-2 shadow-none" name="swim_member_police_station" id="swim_member_police_station"
                                                placeholder="Police Station" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-xl-3">
                                        <div class="form-part mb-3">
                                            <label for="" class="form-label w-100 mb-1 w-100"><small>Age</small></label>
                                            <input type="number" class="form-control py-2 shadow-none" name="swim_age" id="swim_member_age"
                                                placeholder="Age" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-xl-3">
                                        <div class="form-part mb-3">
                                            <label for="" class="form-label w-100 mb-1 w-100"><small>Sex</small></label>
                                            <select name="swim_sex" id="swim_member_sex" class="form-select py-2 shadow-none" required>
                                                <option value="" hidden disabled selected>Sex</option>
                                                <option value="male">Male</option>
                                                <option value="female">Female</option>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-xl-3">
                                        <div class="form-part mb-3">
                                            <label for="" class="form-label w-100 mb-1 w-100"><small>Height</small></label>
                                            <input type="number" class="form-control py-2 shadow-none" name="swim_height" id="swim_member_height"
                                                placeholder="Height" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-xl-3">
                                        <div class="form-part mb-3">
                                            <label for="" class="form-label w-100 mb-1 w-100"><small>Weight</small></label>
                                            <input type="number" class="form-control py-2 shadow-none" name="swim_weight" id="swim_member_weight"
                                                placeholder="Weight" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-xl-3">
                                        <div class="form-part mb-3">
                                            <label for="" class="form-label w-100 mb-1 w-100"><small>Pulse Rate</small></label>
                                            <input type="number" class="form-control py-2 shadow-none" name="swim_pulse_rate" id="swim_member_pulse_rate"
                                                placeholder="Pulse Rate" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-xl-3">
                                        <div class="form-part mb-3">
                                            <label for="" class="form-label w-100 mb-1 w-100"><small>Batch</small></label>
                                            <input type="text" class="form-control py-2 shadow-none" name="swim_batch" id="swim_member_batch"
                                                placeholder="Batch" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-xl-3">
                                        <div class="form-part mb-3">
                                            <label for="" class="form-label w-100 mb-1 w-100"><small>Vaccination</small></label>
                                            <input type="text" class="form-control py-2 shadow-none" name="swim_vaccination" id="swim_member_vaccination"
                                                placeholder="Vaccination" required>
                                        </div>
                                    </div>
                                    <div class="col-md-12">
                                        <div class="form-check mb-3">
                                            <input class="form-check-input" type="checkbox" value="1" name="swim_i_agree" id="swim_member_i_agree" required>
                                            <label class="form-check-label" for="swim_member_i_agree">
                                                <small>I have gone through the rules & Regulations overleaf and undertake to abide by the same at my risk and cost.</small>
                                            </label>
                                        </div>
                                    </div>

                                    <div class="col-lg-8">
                                        <div class="form-part mb-3">
                                            <label for="" class="form-label w-100"><small>I am not suffering
                                                    from</small></label>
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="checkbox" id="inlineCheckbox1"
                                                    value="occational_faint" name="swim_disease[]">
                                                <label class="form-check-label" for="inlineCheckbox1"><small>Any sudden
                                                        or
                                                        occasional faint</small></label>
                                            </div>
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="checkbox" id="inlineCheckbox2"
                                                    value="lung_heart_trouble" name="swim_disease[]">
                                                <label class="form-check-label" for="inlineCheckbox2"><small>Lung/Heart
                                                        trouble</small></label>
                                            </div>
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="checkbox" id="inlineCheckbox3"
                                                    value="skin_disease" name="swim_disease[]">
                                                <label class="form-check-label" for="inlineCheckbox3"><small>Skin
                                                        disease</small></label>
                                            </div>
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="checkbox" id="inlineCheckbox4"
                                                    value="other_disease" name="swim_disease[]">
                                                <label class="form-check-label" for="inlineCheckbox4"><small>Any other
                                                        disease</small></label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-part mb-3">
                                            <label for="" class="form-label w-100 mb-1 w-100"><small>Photo</small></label>
                                            <label class="file-upload-box position-relative text-center border rounded-3 w-100 p-2">
                                                <input type="file" class="file-input opacity-0 position-absolute start-0 w-100 profile-image" name="swim_image" accept=".jpg,.jpeg,.png">
                                                <div class="upload-content">
                                                    <i class="upload-icon"><i
                                                            class="fa-solid fa-arrow-up-from-bracket"></i></i>
                                                    <p class="upload-text mb-0">
                                                        Upload Passport size Image & Signature
                                                    </p>
                                                    <small class="text-muted">
                                                        Image format, PNG & JPEG, max file size 5MB
                                                    </small>
                                                </div>
                                            </label>
                                            <span class="error-div text-danger"></span>
                                        </div>
                                    </div>

                                    <div class="col-md-6 col-xl-3">
                                        <div class="form-part mb-3">
                                            <label for="" class="form-label w-100 mb-1 w-100"><small>Status</small></label>
                                            <select name="swim_status" id="swim_status" class="form-select py-2 shadow-none">
                                                <option value="" hidden disabled selected>Status</option>
                                                <option value="active">Active</option>
                                                <option value="pending">Pending</option>
                                                <option value="rejected">Rejected</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <div class="col-lg-12">
                                <label for="" class="form-label fw-semibold text-dark my-3"><span
                                        class="text-info rounded-3 label-icon p-1 d-inline-flex align-items-center justify-content-center me-2"><i
                                            class="fa-regular fa-user"></i></span> Family Details</label>
                                <div class="row">
                                    <div class="col-lg-4">
                                        <div class="form-part mb-3">
                                            <label for="" class="form-label w-100 mb-1 w-100"><small>Father/Guardian’s Full Name</small></label>
                                            <input type="text" class="form-control py-2 shadow-none" id="swim_guardian_name"
                                                placeholder="Father/Guardian’s Full Name" name="swim_guardian_name" required>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-part mb-3">
                                            <label for="" class="form-label w-100 mb-1 w-100"><small>Father/Guardian’s Occupation</small></label>
                                            <input type="text" class="form-control py-2 shadow-none" id="swim_guardian_occupation"
                                                placeholder="Father/Guardian’s Occupation" name="swim_guardian_occupation" required>
                                        </div>
                                    </div>
                                    <div class="col-lg-4">
                                        <div class="form-part mb-3">
                                            <label for="" class="form-label w-100 mb-1 w-100"><small>Father/Guardian’s Photo</small></label>
                                            <label class="file-upload-box position-relative text-center border rounded-3 w-100 p-2">
                                                <input type="file" class="file-input opacity-0 position-absolute start-0 w-100 profile-image" name="swim_guardian_image" accept=".jpg,.jpeg,.png">
                                                <div class="upload-content">
                                                    <i class="upload-icon"><i
                                                            class="fa-solid fa-arrow-up-from-bracket"></i></i>
                                                    <p class="upload-text mb-0">
                                                        Upload Passport size Image & Signature
                                                    </p>
                                                    <small class="text-muted">
                                                        Image format, PNG & JPEG, max file size 5MB
                                                    </small>
                                                </div>
                                            </label>
                                            <span class="error-div text-danger"></span>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <div class="col-lg-12">
                                <label for="" class="form-label fw-semibold text-dark my-3"><span
                                        class="text-info rounded-3 label-icon p-1 d-inline-flex align-items-center justify-content-center me-2"><i
                                            class="fa-regular fa-regular fa-credit-card"></i></span> Card
                                    Details</label>
                                <div class="row">
                                    <div class="col-12">
                                        <div class="form-part mb-3">
                                            <label for="" class="form-label w-100"><small>Plan type</small></label>

                                            <p id="current_membership"></p>

                                        </div>
                                    </div>
                                    <div class="col-md-6 col-xl-3">
                                        <div class="form-part mb-3">
                                            <label for="" class="form-label w-100 mb-1 w-100"><small>Card No.</small></label>
                                            <select name="swim_card_id" id="swim_card_no" class="form-select py-2 shadow-none">
                                                <option value="" hidden disabled selected>Card No.</option>
                                                @foreach ($cards as $card)
                                                    <option value="{{$card->id}}">{{$card->card_no}}</option>
                                                @endforeach

                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-md-6 col-xl-3">
                                        <div class="form-part mb-3">
                                            <label for="" class="form-label w-100 mb-1 w-100"><small>Current Card No.</small></label>
                                            <p id="current_card_no"></p>
                                        </div>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <div class="text-end mod-footer mt-3">
                            <button type="button" class="btn btn-info fw-semibold"
                                data-bs-dismiss="modal">Cancel</button>
                            <input type="submit" class="btn btn-primary fw-semibold" value="Update Swimming-membership" id="swim_edit_submit">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <!-- add Club Member Modal end  -->

    <!-- View Profile Modal -->
    <div class="modal fade" id="viewprofile" tabindex="-1" aria-labelledby="viewprofileModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-md">
            <div class="modal-content">
                <div class="modal-header border-0">
                    <h5 class="modal-title fs-5 fw-semibold" id="viewprofileModalLabel">Member Plan Details</h5>
                    <button type="button" class="btn-close bg-transparent fs-5 lh-1" data-bs-dismiss="modal"
                        aria-label="Close"><i class="fa-regular fa-circle-xmark"></i></button>
                </div>
                <div class="modal-body">
                    <table class="table border-0 membership-plan-table" cellspacing="1" cellpadding="1">
                        <tbody>
                            <tr>
                                <td class="text-secondary ps-3">
                                    <small>Member’s Name:</small>
                                </td>
                                <td class="pe-3"><small id="memberName">Soumen Das</small></td>
                            </tr>
                            <tr>
                                <td class="text-secondary ps-3">
                                    <small>Club Name:</small>
                                </td>
                                <td class="pe-3"><small id="memberClubName">Soumen Das</small></td>
                            </tr>
                            <tr>
                                <td class="text-secondary ps-3">
                                    <small>Member’s Id:</small>
                                </td>
                                <td class="pe-3"><small id="memberCode">GH231</small></td>
                            </tr>
                            <tr>
                                <td class="text-secondary ps-3">
                                    <small>Card No:</small>
                                </td>
                                <td class="pe-3"><small id="memberCardNo">12345abcd</small></td>
                            </tr>
                            {{-- <tr>
                                <td class="text-secondary ps-3">
                                    <small>Card No:</small>
                                </td>
                                <td class="pe-3"><small>12345abcd</small></td>
                            </tr> --}}
                            <tr>
                                <td class="text-secondary ps-3">
                                    <small>Current Active Plan:</small>
                                </td>
                                <td class="pe-3"><small id="memberPlan">Gold</small></td>
                            </tr>
                            <tr>
                                <td class="text-secondary ps-3">
                                    <small>Plan Expiry Date:</small>
                                </td>
                                <td class="pe-3"><small id="memberPlanExpiry">12-31-2006</small></td>
                            </tr>
                            <tr>
                                <td class="text-secondary ps-3">
                                    <small>Current Wallet Balance:</small>
                                </td>
                                <td class="pe-3"><small id="memberWallet">₹2,450.00</small></td>
                            </tr>
                            <tr>
                                <td class="text-secondary ps-3">
                                    <small>Approved By:</small>
                                </td>
                                <td class="pe-3"><small id="memberApprovedBy">₹2,450.00</small></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Plan Renewal Modal -->
    <div class="modal fade" id="planrenewal" tabindex="-1" aria-labelledby="planrenewalModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header border-0">
                    <h5 class="modal-title fs-5 fw-semibold" id="planrenewalModalLabel">Renewal Plan</h5>
                    <button type="button" class="btn-close bg-transparent fs-5 lh-1" data-bs-dismiss="modal"
                        aria-label="Close"><i class="fa-regular fa-circle-xmark"></i></button>
                </div>
                <div class="modal-body">
                    <form action="">
                        <div class="row">
                            <div class="col-12">
                                <label for="" class="form-label fw-semibold text-dark mb-3"><span
                                        class="text-info rounded-3 label-icon p-1 d-inline-flex align-items-center justify-content-center me-2"><i
                                            class="fa-regular fa-user"></i></span>Personal Details</label>
                                <div class="row">
                                    <div class="col-lg-6">
                                        <div class="form-part mb-3">
                                            <label for="" class="form-label w-100"><small>Renewal type</small></label>
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="radio" name="renewinlineRadioOptions"
                                                    id="renewinlineRadio1" value="option1">
                                                <label class="form-check-label"
                                                    for="renewinlineRadio1"><small>Annual</small></label>
                                            </div>
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="radio" name="renewinlineRadioOptions"
                                                    id="renewinlineRadio2" value="option2">
                                                <label class="form-check-label"
                                                    for="renewinlineRadio2"><small>Lifetime</small></label>
                                            </div>
                                            <div class="form-check form-check-inline">
                                                <input class="form-check-input" type="radio" name="renewinlineRadioOptions"
                                                    id="renewinlineRadio3" value="option3">
                                                <label class="form-check-label"
                                                    for="renewinlineRadio3"><small>Silver</small></label>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-part mb-3">
                                            <input type="text" class="form-control py-2 shadow-none" id=""
                                                placeholder="Mode">
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-part mb-3">
                                            <input type="text" class="form-control py-2 shadow-none" id=""
                                                placeholder="A/C Head">
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-part mb-3">
                                            <input type="text" class="form-control py-2 shadow-none" id=""
                                                placeholder="Fine">
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-part mb-3">
                                            <input type="text" class="form-control py-2 shadow-none" id=""
                                                placeholder="Taxable Amt (Min 500)">
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-part mb-3">
                                            <input type="text" class="form-control py-2 shadow-none" id=""
                                                placeholder="GST%">
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-part mb-3">
                                            <input type="text" class="form-control py-2 shadow-none" id="" placeholder="GST Amt">
                                        </div>
                                    </div>
                                    <div class="col-lg-6">
                                        <div class="form-part mb-3">
                                            <input type="text" class="form-control py-2 shadow-none" id=""
                                                placeholder="Receipt Amt">
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-part mb-3">
                                            <input type="text" class="form-control py-2 shadow-none" id=""
                                                placeholder="Bank Name">
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <div class="form-part mb-3">
                                            <textarea class="form-control py-2 shadow-none" id="" rows="3"
                                                placeholder="Remarks"></textarea>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="text-end mod-footer mt-3">
                            <button type="button" class="btn btn-info fw-semibold"
                                data-bs-dismiss="modal">Cancel</button>
                            <input type="submit" class="btn btn-primary fw-semibold" value="Submit">
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- wallet Modal -->
    <div class="modal fade" id="walletrecharge" tabindex="-1" aria-labelledby="walletrechargeModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header border-0">
                    <h5 class="modal-title fs-5 fw-semibold" id="walletrechargeModalLabel">Wallet Recharge</h5>
                    <button type="button" class="btn-close bg-transparent fs-5 lh-1" data-bs-dismiss="modal"
                        aria-label="Close"><i class="fa-regular fa-circle-xmark"></i></button>
                </div>
                <div class="modal-body">
                    <div class="card current-balance border-0 p-1 mb-4">
                        <div class="card-body">
                            <p class="card-text fw-semibold mb-2 text-white">Current Balance</p>
                            <h5 class="card-title fs-4 fw-semibold text-white mb-0" id="walletBalance"></h5>
                        </div>
                    </div>
                    <form action="" id="walletRechargeForm" method="post">
                        @csrf
                        <input type="hidden" name="wallet_member_id" id="walletMemberId" value="">
                        <div class="row">
                            <div class="col-12">
                                <div class="input-group mb-3">
                                    <label for="" class="form-label w-100 mb-1 w-100"><small>Balance</small></label>
                                    <span
                                        class="input-group-text bg-transparent border-end-0 bg-white"><small>₹</small></span>
                                    <input id="amountInput" type="number" class="form-control border-start-0 shadow-none"
                                        aria-label="Amount" name="wallet_recharge_amount" placeholder="0" min="500" step="1" required>

                                </div>
                                <span class="error-div text-danger" id="amountErrorDiv"></span>
                            </div>
                            <div class="col-12">
                                <label for="" class="form-label fw-semibold text-dark mb-3">Quick Select</label>
                                <div class="row">
                                    <div class="col-xl-3 col-md-6">
                                        <div class="form-check position-relative p-0 custom-radio mb-3">
                                            <input
                                                class="form-check-input m-0 w-100 h-100 position-absolute top-0 start-0 rounded-0 opacity-0"
                                                type="radio" name="inlineRadioOptions" id="inlineRadio1"
                                                value="option1">
                                            <label class="form-check-label w-100 border p-2 rounded-3"
                                                for="inlineRadio1"><small>₹ 500</small></label>
                                        </div>
                                    </div>
                                    <div class="col-xl-3 col-md-6">
                                        <div class="form-check position-relative p-0 custom-radio mb-3">
                                            <input
                                                class="form-check-input m-0 w-100 h-100 position-absolute top-0 start-0 rounded-0 opacity-0"
                                                type="radio" name="inlineRadioOptions" id="inlineRadio2"
                                                value="option1">
                                            <label class="form-check-label w-100 border p-2 rounded-3"
                                                for="inlineRadio2"><small>₹ 1000</small></label>
                                        </div>
                                    </div>
                                    <div class="col-xl-3 col-md-6">
                                        <div class="form-check position-relative p-0 custom-radio mb-3">
                                            <input
                                                class="form-check-input m-0 w-100 h-100 position-absolute top-0 start-0 rounded-0 opacity-0"
                                                type="radio" name="inlineRadioOptions" id="inlineRadio3"
                                                value="option1">
                                            <label class="form-check-label w-100 border p-2 rounded-3"
                                                for="inlineRadio3"><small>₹ 2000</small></label>
                                        </div>
                                    </div>
                                    <div class="col-xl-3 col-md-6">
                                        <div class="form-check position-relative p-0 custom-radio mb-3">
                                            <input
                                                class="form-check-input m-0 w-100 h-100 position-absolute top-0 start-0 rounded-0 opacity-0"
                                                type="radio" name="inlineRadioOptions" id="inlineRadio4"
                                                value="option1">
                                            <label class="form-check-label w-100 border p-2 rounded-3"
                                                for="inlineRadio4"><small>₹ 5000</small></label>
                                        </div>
                                    </div>
                                </div>

                            </div>
                            <div class="col-md-6 col-xl-6">
                                <div class="form-part mb-3">
                                    <label for="" class="form-label w-100 mb-1 w-100"><small>Payment Mode</small></label>
                                    <input type="text" class="form-control py-2 shadow-none" id="" name="wallet_payment_mode"
                                        placeholder="Payment Mode" required>
                                </div>
                            </div>
                            <div class="col-md-6 col-xl-6">
                                <div class="form-part mb-3">
                                    <label for="" class="form-label w-100 mb-1 w-100"><small>A/C Head</small></label>
                                    <input type="text" class="form-control py-2 shadow-none" id="" name="wallet_ac_head"
                                        placeholder="A/C Head" required>
                                </div>
                            </div>
                            <div class="col-md-6 col-xl-6">
                                <div class="form-part mb-3">
                                    <label for="" class="form-label w-100 mb-1 w-100"><small>Bank Name</small></label>
                                    <select name="wallet_bank_id" id="" class="form-select py-2 shadow-none" required>
                                        <option value="" hidden disabled selected>Bank Name</option>
                                        @foreach ($bankList as $bank)
                                            <option value="{{$bank->id}}">{{$bank->name}}</option>
                                        @endforeach

                                    </select>
                                </div>
                            </div>
                            <div class="col-md-6 col-xl-6">
                                <div class="form-part mb-3">
                                    <label for="" class="form-label w-100 mb-1 w-100"><small>Remarks</small></label>
                                    <input type="text" class="form-control py-2 shadow-none" id="" name="wallet_remarks"
                                        placeholder="Remarks" required>
                                </div>
                            </div>
                        </div>
                        <div class="text-end">
                            <button class="btn btn-primary fw-semibold" id="rechargeSubmitBtn">Recharge Wallet</button>
                        </div>
                    </form>
                    <div class="d-flex justify-content-between align-items-center gap-3 my-4">
                        <div class="form-label fw-semibold text-dark mb-3"><span
                                class="text-info rounded-3 label-icon p-1 d-inline-flex align-items-center justify-content-center me-2"><i
                                    class="fa-solid fa-wallet"></i></span> Recent Transactions</div>
                        <span><a class="text-dark"><i class="fa-regular fa-calendar fs-4"></i></a></span>
                    </div>
                    <div class="bg-light p-2">
                        <table class="table border-0 m-0 wallet-table" id="walletTransactionTbody">
                            <tbody>
                                <tr>
                                    <td class="border-secondary bg-transparent align-middle lh-sm">
                                        <small class="fw-semibold">Added</small> <br>
                                        <small class="text-black-50">Today, 2:30 PM</small>
                                    </td>
                                    <td class="text-success text-end border-secondary bg-transparent align-middle">
                                        +₹4000</td>
                                </tr>
                                <tr>
                                    <td class="border-secondary bg-transparent align-middle lh-sm">
                                        <small class="fw-semibold">Added</small> <br>
                                        <small class="text-black-50">Today, 2:30 PM</small>
                                    </td>
                                    <td class="text-info text-end border-secondary bg-transparent align-middle">
                                        +₹4000</td>
                                </tr>
                                <tr>
                                    <td class="border-secondary bg-transparent align-items-center align-middle lh-sm">
                                        <small class="fw-semibold">Usd</small> <br>
                                        <small class="text-black-50">Today, 2:30 PM</small>
                                    </td>
                                    <td class="text-danger text-end border-secondary bg-transparent align-middle">+₹4000
                                    </td>
                                </tr>
                            </tbody>
                        </table>
                    </div>

                </div>
            </div>
        </div>
    </div>

    <!-- Membership plan Modal -->
    <div class="modal fade" id="membershipplan" tabindex="-1" aria-labelledby="membershipplanModalLabel"
        aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header border-0">
                    <h5 class="modal-title fs-5 fw-semibold" id="membershipplanModalLabel">Membership Plan History</h5>
                    <button type="button" class="btn-close bg-transparent fs-5 lh-1" data-bs-dismiss="modal"
                        aria-label="Close"><i class="fa-regular fa-circle-xmark"></i></button>
                </div>
                <div class="modal-body">
                    <div class="table-responsive">
                        <table class="table border-0 membership-plan-table">
                            <tbody id="membershipPlanTbody">
                                {{-- <tr class="active-member">
                                    <td class="bg-info align-middle p-3 text-nowrap">
                                        <small class="fw-semibold">From Date</small> <br>
                                        <small class="text-black-50">01.01.2026</small>
                                    </td>
                                    <td class="bg-info align-middle p-3 text-nowrap">
                                        <small class="fw-semibold">To Date</small> <br>
                                        <small class="text-black-50">01.01.2026</small>
                                    </td>
                                    <td class="bg-info align-middle p-3 text-nowrap">
                                        <small class="fw-semibold">Plan Type</small> <br>
                                        <small class="text-black-50">Annual</small>
                                    </td>
                                    <td class="bg-info align-middle p-3 text-nowrap">
                                        <small class="fw-semibold">Fine</small> <br>
                                        <small class="text-black-50">Rs 00.00</small>
                                    </td>
                                    <td class="bg-info align-middle p-3 text-nowrap">
                                        <small class="fw-semibold">Price</small> <br>
                                        <small class="text-black-50">Rs 00.00</small>
                                    </td>
                                    <td class="bg-info align-middle text-end p-3">
                                        <img src="{{ asset('assets/images/active-tag.svg') }}" alt="" width="76" height="67"
                                            style="min-width: 76px;">
                                    </td>
                                </tr>
                                <tr class="expire-member">
                                    <td class="bg-info align-middle p-3 text-nowrap">
                                        <small class="fw-semibold">From Date</small> <br>
                                        <small class="text-black-50">01.01.2026</small>
                                    </td>
                                    <td class="bg-info align-middle p-3 text-nowrap">
                                        <small class="fw-semibold">To Date</small> <br>
                                        <small class="text-black-50">01.01.2026</small>
                                    </td>
                                    <td class="bg-info align-middle p-3 text-nowrap">
                                        <small class="fw-semibold">Plan Type</small> <br>
                                        <small class="text-black-50">Annual</small>
                                    </td>
                                    <td class="bg-info align-middle p-3 text-nowrap">
                                        <small class="fw-semibold">Fine</small> <br>
                                        <small class="text-black-50">Rs 00.00</small>
                                    </td>
                                    <td class="bg-info align-middle p-3 text-nowrap">
                                        <small class="fw-semibold">Price</small> <br>
                                        <small class="text-black-50">Rs 00.00</small>
                                    </td>
                                    <td class="bg-info align-middle p-3 text-nowrap">
                                        <img src="{{ asset('assets/images/expire-tag.svg') }}" alt="" class="position-absolute end-0"
                                            style="top: 10px;" width="73" height="24" style="min-width: 73px;">
                                    </td>
                                </tr> --}}
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Delete row table Modal -->
    <div class="modal fade" id="deleteConfirmModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content rounded-3">
                <div class="modal-header border-0">
                    <h5 class="modal-title">Confirm Delete</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <p class="mb-0">Are you sure you want to delete this row?</p>
                </div>
                <div class="modal-footer border-0">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        Cancel
                    </button>
                    <button type="button" class="btn btn-danger" id="confirmDeleteBtn" data-id="">
                        Yes, Delete
                    </button>
                </div>
            </div>
        </div>
    </div>

    <!-- Wallet Recharge Confirm Modal -->
    <div class="modal fade" id="walletRechargeConfirmModal" tabindex="-1">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content rounded-3">
                <div class="modal-header border-0">
                    <h5 class="modal-title">Confirm Wallet Recharge</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>

                <div class="modal-body">
                    <p class="mb-0">Are you sure you want to recharge this wallet?</p>
                </div>

                <div class="modal-footer border-0">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                        Cancel
                    </button>

                    <button type="button" class="btn btn-success" id="confirmRechargeBtn">
                        Yes, Recharge
                    </button>
                </div>
            </div>
        </div>
    </div>

@endsection

@section('customJS')
<script>
    $(document).ready(function() {

        // const params = new URLSearchParams(window.location.search);

        const params = new URLSearchParams(window.location.search);
        const type = params.get('type');

        // Check if 'type' parameter is 'addMember'
        if (type === 'addMember') {
            $('#addSwimmingMemberBtn').trigger('click');
        }



        //name validation
        $('.text-only').on('input', function () {
            this.value = this.value.replace(/[^A-Za-z\s]/g, '');
        });

        //phone no validation
        $('.phone-input').on('input', function () {
            this.value = this.value.replace(/\D/g, '').slice(0, 10);
        });

        function calculateGST() {
            // Get values from inputs
            let taxable = parseFloat($('#taxable_amount').val()) || 0;
            let gstPercent = parseFloat($('#gstPercentage').val()) || 0;

            // Calculate GST Amount
            let gstAmount = (taxable * gstPercent) / 100;

            // Calculate Receipt Amount (Taxable + GST)
            let receiptAmount = taxable + gstAmount;

            // Update the readonly inputs
            $('#gstAmt').val(gstAmount.toFixed(2));
            $('#receiptAmt').val(receiptAmount.toFixed(2));
        }

        // Bind calculation on keyup/change for Taxable Amt and GST%
        $('#taxable_amount, #gstPercentage').on('keyup change', calculateGST);

        $('#swimmingMemberForm').on('submit', function (e) {
            e.preventDefault();

            const $btn = $('#swim_submit');
            const originalText = $btn.val();

            let isValid = true;
            $('.phone-input').each(function () {

                let phone = $(this).val();
                let errorDiv = $(this).next('.error-div');

                if (phone !== '' && !/^\d{10}$/.test(phone)) {
                    errorDiv.text('Phone number must be 10 digits.');
                    $(this).addClass('is-invalid');
                    isValid = false;

                } else {
                    $(this).removeClass('is-invalid');
                    errorDiv.text('');
                }
            });

            $('.profile-image').each(function () {

                let fileInput = this;
                let errorDiv = $(this).closest('.form-part').find('.error-div');

                if (fileInput.files.length > 0) {

                    let file = fileInput.files[0];
                    let allowedTypes = ['image/jpeg', 'image/png'];
                    let maxSize = 5 * 1024 * 1024; // 2MB

                    let errors = [];

                    if (!allowedTypes.includes(file.type)) {
                        errors.push('Only JPG, JPEG and PNG images are allowed.');
                    }

                    if (file.size > maxSize) {
                        errors.push('Image must be less than 5MB.');
                    }

                    if (errors.length > 0) {
                        isValid = false;
                        errorDiv.html(errors.join('<br>'));
                        $(this).addClass('is-invalid');
                    } else {
                        errorDiv.text('');
                        $(this).removeClass('is-invalid');
                    }
                } else {
                    // If optional field → clear error
                    errorDiv.text('');
                    $(this).removeClass('is-invalid');
                }

            });

            let taxableAmt = $('#taxable_amount').val();
            let errorDiv = $(this).next('.error-div');

            if (taxableAmt === '' || isNaN(taxableAmt) || parseFloat(taxableAmt) <= 0) {
                errorDiv.text('Please enter a valid taxable amount.');
                $('#taxable_amount').addClass('is-invalid');
                isValid = false;
            } else {
                errorDiv.text('');
                $('#taxable_amount').removeClass('is-invalid');
            }

            let gstPercentage = $('#gstPercentage').val();

            if (gstPercentage === '' || isNaN(gstPercentage) || parseFloat(gstPercentage) <= 0) {
                errorDiv.text('Please enter a valid gst percentage.');
                $('#gstPercentage').addClass('is-invalid');
                isValid = false;
            } else {
                errorDiv.text('');
                $('#gstPercentage').removeClass('is-invalid');
            }

            if (!isValid) {
                return isValid;
            }

            $btn.prop('disabled', true);
            $btn.html('<span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>Processing...');

            let swimmingMemberformData = new FormData($("#swimmingMemberForm")[0]);
            $.ajax({
                url: "{{ route('swimming-member.store') }}",
                type: "POST",
                data: swimmingMemberformData,
                processData: false,
                contentType: false,
                // data:{
                // "_token": "{{ csrf_token() }}",
                // "balance": balance,
                // "user_id": userId
                // },
                success: function(response) {
                    if (response.statusCode == 200) {
                        $btn.html(originalText);
                        toastr.success(response.message);
                        // setTimeout(() => location.reload(), 1500);
                        setTimeout(() => {
                            window.location.href = "{{ route('swimming-member.list') }}";
                        }, 1500);

                    } else {
                        $btn.html(originalText);
                        $btn.prop('disabled', false);

                        if(response.message){
                            toastr.error(response.message);
                        }
                        else{
                            toastr.error("Something went wrong, Please try again.");
                            // console.log(response)
                        }
                    }
                },
                error: function(xhr, status, error) {
                    $btn.html(originalText);
                    $btn.prop('disabled', false);
                    toastr.error("Something went wrong, Please try again.");

                    let responseError = xhr.responseJSON?.error
                        ?? "Something went wrong, Please try again.";
                    console.error(responseError);
                }
            });

        });

        $('.plan-type').on('change', function () {

            let planTypeId = $(this).val();
            let gstPercentage = $('#gstPercentage').val();

            $.ajax({
                url: "{{ route('swimming-member.plan-price') }}",
                type: "GET",
                data: {
                    planTypeId: planTypeId
                },
                success: function (response) {
                    if (response.statusCode == 200) {
                        $('#taxable_amount').val(response.data.plan.price);
                        let price = parseFloat(response.data.plan.price);
                        let gstAmt = ((price * gstPercentage)/100).toFixed(2);
                        let receiptAmt = (price + parseFloat(gstAmt)).toFixed(2);

                        $('#gstAmt').val(gstAmt);
                        $('#receiptAmt').val(receiptAmt);

                    } else {
                        if(response.message){
                            toastr.error(response.message);
                        }
                        else{
                            toastr.error("Something went wrong, Please try again.");
                        }
                    }
                },
                error: function(xhr, status, error) {
                    // Handle errors
                    toastr.error("Something went wrong, Please try again.");
                    console.error(xhr.responseText);
                }
            });

        });

        $(document).on('click', '.viewProfileBtn', function() {
            let memberId = $(this).data('id');
            let originalBtn = $(this).prop('outerHTML'); // save original button
            $(this).replaceWith('<span class="spinner-border spinner-border-sm text-primary"></span>');

            $.ajax({
                url: '{{route("swimming-member.view", ":memberId")}}'.replace(':memberId', memberId),
                type: 'GET',
                success: function(response){
                    if (response.statusCode == 200) {
                        // console.log(response);
                        $('#memberName').text(response.data.name);
                        $('#memberClubName').text(response.data.club_details.name)
                        $('#memberCode').text(response.data.member_code)
                        $('#memberCardNo').text(response.data.card_details?.card_no || '-')

                        $('#memberApprovedBy').text(response.data.latest_approval?.checker?.name ?? '-');

                        // $('#memberPlan').text(response.data.purchase_history[0].membership_plan_type.name)
                        // let expiryDate = response.data.purchase_history[0].expiry_date;
                        // let formatted = new Date(expiryDate).toLocaleDateString('en-IN'); // d/m/y format
                        // $('#memberPlanExpiry').text(formatted);
                        const purchase = response.data.purchase_history?.[0];

                        $('#memberPlan').text(
                            purchase?.status === 'active'
                                ? purchase?.membership_plan_type?.name ?? 'No Active Plan'
                                : 'No Active Plan'
                        );
                        // $('#memberPlan').text(response.data.purchase_history[0].membership_plan_type.name)
                        let formatted = 'NA';
                        if (purchase?.status === 'active' && purchase?.expiry_date) {
                            formatted = new Date(purchase.expiry_date).toLocaleDateString('en-IN');
                        }
                        $('#memberPlanExpiry').text(formatted);
                        $('#memberWallet').text('₹ ' + (response.data.wallet_details?.current_balance??0));

                        $('.spinner-border').replaceWith(originalBtn);
                        $('#viewprofile').modal('show');
                    }
                    else{
                        // toastr.error('Something Went Wrong').
                        // console.log(response);
                    }

                },
                error: function(){
                    toastr.error('Something Went Wrong.');
                }
            });
        });

        $(document).on('click', '.memberDeleteBtn', function() {
            // $('.memberDeleteBtn').on('click', function(){
            $('#confirmDeleteBtn').data('id', $(this).data('id'));
        });

        $(document).on('click', '#confirmDeleteBtn', function() {
            // $('#confirmDeleteBtn').on('click', function(){
            let memberId = $(this).data('id');
            // let originalBtn = $(this).prop('outerHTML'); // save original button
            // $(this).replaceWith('<span class="spinner-border spinner-border-sm text-danger"></span>');

            $.ajax({
                url: '{{route("swimming-member.delete", ":memberId")}}'.replace(':memberId', memberId),
                type: 'GET',
                success: function(response){
                    if (response.statusCode == 200) {
                        toastr.success(response.message);

                        // $('.spinner-border').replaceWith(originalBtn);
                    }
                    else{
                        toastr.error('Something Went Wrong');
                        // console.log(response);
                    }

                },
                error: function(){
                    toastr.error('Something Went Wrong.');
                }
            });
        });

        $(document).on('click', '.memberEditBtn', function() {
            let memberId = $(this).data('id');
            let originalBtn = $(this).prop('outerHTML'); // save original button
            $(this).replaceWith('<span class="spinner-border spinner-border-sm text-primary"></span>');

            $.ajax({
                url: '{{route("swimming-member.view", ":memberId")}}'.replace(':memberId', memberId),
                type: 'GET',
                success: function(response){
                    if (response.statusCode == 200) {
                        // console.log(response);
                        $('#swim_member_id').val(memberId)
                        $('#swim_member_name').val(response.data.name);
                        $('#swim_member_email').val(response.data.email);
                        $('#swim_member_phone').val(response.data.phone);
                        $('#swim_member_address').val(response.data.address);
                        $('#swim_member_police_station').val(response.data.member_details.details['police_station']);
                        $('#swim_member_age').val(response.data.member_details.details['age']);
                        $('#swim_member_sex').val(response.data.member_details.details['sex']);
                        $('#swim_member_height').val(response.data.member_details.details['height']);
                        $('#swim_member_weight').val(response.data.member_details.details['weight']);
                        $('#swim_member_pulse_rate').val(response.data.member_details.details['pulse_rate']);
                        $('#swim_member_batch').val(response.data.member_details.details['batch']);
                        $('#swim_member_vaccination').val(response.data.member_details.details['vaccination']);
                        $('#swim_member_i_agree').prop('checked', response.data.member_details.details['i_agree'] == 1);
                        let diseases = response.data.member_details.details['disease'];
                        $('input[name="swim_disease[]"]').prop('checked', false);
                        if(diseases && diseases.length > 0){
                            diseases.forEach(function(disease) {
                                $('input[name="swim_disease[]"][value="' + disease + '"]').prop('checked', true);
                            });
                        }
                        $('#swim_status').val(response.data.status);
                        $('#swim_guardian_name').val(response.data.member_details.details['guardian_name']);
                        $('#swim_guardian_occupation').val(response.data.member_details.details['guardian_occupation']);
                        let planTypeId = response.data.purchase_history[0].membership_plan_type_id;
                        $('input[name="swim_membership_plan_type"]').prop('checked', false);
                        $('input[name="swim_membership_plan_type"][value="' + planTypeId + '"]').prop('checked', true);
                        $('#current_card_no').text(response.data.card_details.card_no);
                        // console.log(response.purchase_history);
                        $('#current_membership').text(response.data.purchase_history[0].membership_plan_type.name)

                        $('.spinner-border').replaceWith(originalBtn);
                        $('#editswimmingmember').modal('show');
                    }
                    else{
                        // toastr.error('Something Went Wrong').
                        // console.log(response);
                    }

                },
                error: function(){
                    toastr.error('Something Went Wrong.');
                }
            });


        });

        $(document).on('click', '.membershipPlanBtn', function() {
            let memberId = $(this).data('id');
            let originalBtn = $(this).prop('outerHTML'); // save original button
            $(this).replaceWith('<span class="spinner-border spinner-border-sm text-primary"></span>');

            $.ajax({
                url: '{{route("swimming-member.membership-plan", ":memberId")}}'.replace(':memberId', memberId),
                type: 'GET',
                success: function(response){
                    if (response.statusCode == 200) {
                        let tbody = $('#membershipPlanTbody');
                        tbody.empty();

                        response.data.forEach(function(plan) {
                            let fromDate = new Date(plan.start_date).toLocaleDateString('en-IN', { timeZone: 'Asia/Kolkata' });
                            let toDate = new Date(plan.expiry_date).toLocaleDateString('en-IN', { timeZone: 'Asia/Kolkata' });
                            let today = new Date();
                            let expiryDate = new Date(plan.expiry_date);
                            let isActive = expiryDate >= today;

                            let row = `
                                <tr>
                                    <td class="bg-info align-middle p-3 text-nowrap">
                                        <small class="fw-semibold">From Date</small> <br>
                                        <small class="text-black-50">${fromDate}</small>
                                    </td>
                                    <td class="bg-info align-middle p-3 text-nowrap">
                                        <small class="fw-semibold">To Date</small> <br>
                                        <small class="text-black-50">${toDate}</small>
                                    </td>
                                    <td class="bg-info align-middle p-3 text-nowrap">
                                        <small class="fw-semibold">Plan Type</small> <br>
                                        <small class="text-black-50">${plan.membership_plan_type.name}</small>
                                    </td>
                                    <td class="bg-info align-middle p-3 text-nowrap">
                                        <small class="fw-semibold">Fine</small> <br>
                                        <small class="text-black-50">Rs ${plan.fine_amount}</small>
                                    </td>
                                    <td class="bg-info align-middle p-3 text-nowrap">
                                        <small class="fw-semibold">Price</small> <br>
                                        <small class="text-black-50">Rs ${plan.net_amount}</small>
                                    </td>
                                    <td class="bg-info align-middle text-end p-3">
                                        <img src="{{ asset('assets/images') }}${isActive ? '/active-tag.svg' : '/expire-tag.svg'}" alt="" width="${isActive ? 76 : 73}" height="${isActive ? 67 : 24}">
                                    </td>
                                </tr>`;

                            tbody.append(row);
                        });

                        $('.spinner-border').replaceWith(originalBtn);
                        $('#membershipplan').modal('show')
                    }
                    else{
                        // toastr.error('Something Went Wrong').
                        // console.log(response);
                    }

                },
                error: function(){
                    toastr.error('Something Went Wrong.');
                }
            });

        });

        $(document).on('click', '.walletRechargeBtn', function() {
            let memberId = $(this).data('id');
            let originalBtn = $(this).prop('outerHTML'); // save original button
            $(this).replaceWith('<span class="spinner-border spinner-border-sm text-primary"></span>');

            $.ajax({
                url: '{{route("swimming-member.fetch-wallet-balance", ":memberId")}}'.replace(':memberId', memberId),
                type: 'GET',
                success: function(response){
                    if (response.statusCode == 200) {
                        // console.log(response);
                        $('#walletMemberId').val(memberId);
                        $('#walletBalance').text('₹' + (response.data.walletBalance ?? 0.00));

                        let tbody = $('#walletTransactionTbody');
                        tbody.empty();

                        if(response.data.walletTransactionHistory.length > 0){
                            response.data.walletTransactionHistory.forEach(function(transaction) {
                                let amount = transaction.amount;
                                let direction = transaction.direction;
                                let date = new Date(transaction.created_at).toLocaleDateString('en-IN', { timeZone: 'Asia/Kolkata' });
                                let amountClass = direction == 'credit' ? 'text-success' : 'text-danger';
                                let sign = direction == 'credit' ? '+' : '-';
                                let label = direction == 'credit' ? 'Added By' : 'Used';
                                let maker = transaction.creator?.name ?? '-';
                                let remarks = transaction.payment?.remarks ?? '';

                                let row = `
                                    <tr>
                                        <td class="border-secondary bg-transparent align-middle lh-sm">
                                            <small class="fw-semibold">${label}:</small>
                                            <small class="text-black-50">${maker}</small>

                                            ${remarks ? `<br>
                                            <small class="fw-semibold">Remarks:</small>
                                            <small class="text-black-50">${remarks}</small>` : ''}

                                        </td>


                                        <td class="${amountClass} text-end border-secondary bg-transparent align-middle">
                                            ${sign}₹${amount}
                                        </td>
                                    </tr>`;

                                tbody.append(row);
                            });
                        } else {
                            tbody.append('<tr><td colspan="2" class="text-center">No transactions found</td></tr>');
                        }


                        $('.spinner-border').replaceWith(originalBtn);
                        $('#walletrecharge').modal('show');
                    }
                    else{
                        // toastr.error('Something Went Wrong').
                        // console.log(response);
                    }

                },
                error: function(){
                    toastr.error('Something Went Wrong.');
                }
            });

        });

        $('#walletRechargeForm').on('submit', function (e) {
            e.preventDefault();

            $('#walletRechargeConfirmModal').modal('show');
        });

        $(document).on('click', '#confirmRechargeBtn', function () {

            $('#walletRechargeConfirmModal').modal('hide');

            $('#rechargeSubmitBtn')
                .prop('disabled', true)
                .html('<span class="spinner-border spinner-border-sm me-2"></span> Processing...');

            let walletRechargeMemberformData = new FormData($("#walletRechargeForm")[0]);

            $.ajax({
                url: "{{ route('swimming-member.recharge-wallet-balance') }}",
                type: "POST",
                data: walletRechargeMemberformData,
                processData: false,
                contentType: false,

                success: function(response) {

                    if (response.statusCode == 200) {

                        toastr.success(response.message);

                        setTimeout(() => {
                            window.location.href = "{{ route('swimming-member.list') }}";
                        }, 1500);

                    } else {

                        toastr.error(response.message ?? "Something went wrong");

                        $('#rechargeSubmitBtn')
                            .prop('disabled', false)
                            .html('Recharge Wallet');
                    }
                },

                error: function() {

                    toastr.error("Something went wrong, Please try again.");

                    $('#rechargeSubmitBtn')
                        .prop('disabled', false)
                        .html('Recharge Wallet');
                }
            });

        });

        $('#swimmingMemberEditForm').on('submit', function (e) {
            e.preventDefault();
            const $btn = $('#swim_edit_submit');
            const originalText = $btn.val(); // store original button text

            let isValid = true;
            $('.phone-input').each(function () {

                let phone = $(this).val();
                let errorDiv = $(this).next('.error-div');

                if (phone !== '' && !/^\d{10}$/.test(phone)) {
                    errorDiv.text('Phone number must be 10 digits.');
                    $(this).addClass('is-invalid');
                    isValid = false;

                } else {
                    $(this).removeClass('is-invalid');
                    errorDiv.text('');
                }
            });

            $('.profile-image').each(function () {

                let fileInput = this;
                let errorDiv = $(this).closest('.form-part').find('.error-div');

                if (fileInput.files.length > 0) {

                    let file = fileInput.files[0];
                    let allowedTypes = ['image/jpeg', 'image/png'];
                    let maxSize = 5 * 1024 * 1024; // 2MB

                    let errors = [];

                    if (!allowedTypes.includes(file.type)) {
                        errors.push('Only JPG, JPEG and PNG images are allowed.');
                    }

                    if (file.size > maxSize) {
                        errors.push('Image must be less than 5MB.');
                    }

                    if (errors.length > 0) {
                        isValid = false;
                        errorDiv.html(errors.join('<br>'));
                        $(this).addClass('is-invalid');
                    } else {
                        errorDiv.text('');
                        $(this).removeClass('is-invalid');
                    }
                } else {
                    // If optional field → clear error
                    errorDiv.text('');
                    $(this).removeClass('is-invalid');
                }

            });

            if (!isValid) {
                return isValid;
            }

            $btn.prop('disabled', true);
            $btn.html('<span class="spinner-border spinner-border-sm me-2" role="status" aria-hidden="true"></span>Processing...');

            let swimmingMemberEditformData = new FormData($("#swimmingMemberEditForm")[0]);
            $.ajax({
                url: "{{ route('swimming-member.update') }}",
                type: "POST",
                data: swimmingMemberEditformData,
                processData: false,
                contentType: false,
                // data:{
                // "_token": "{{ csrf_token() }}",
                // "balance": balance,
                // "user_id": userId
                // },
                success: function(response) {
                    // console.log(response);
                    if (response.statusCode == 200) {
                        $btn.html(originalText);
                        toastr.success(response.message);
                        // setTimeout(() => location.reload(), 1500);
                        setTimeout(() => {
                            window.location.href = "{{ route('swimming-member.list') }}";
                        }, 1500);

                    } else {
                        $btn.html(originalText);
                        $btn.prop('disabled', false);
                        if(response.message){
                            toastr.error(response.message);
                        }
                        else{
                            toastr.error("Something went wrong, Please try again.");
                            // console.log(response)
                        }
                    }
                },
                error: function(xhr, status, error) {
                    $btn.html(originalText);
                    $btn.prop('disabled', false);
                    toastr.error("Something went wrong, Please try again.");

                    let responseError = xhr.responseJSON?.error
                        ?? "Something went wrong, Please try again.";
                    console.error(responseError);
                }
            });

        });

    });
</script>
@endsection
