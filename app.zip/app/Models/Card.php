<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Card extends Model
{
    use SoftDeletes;

    protected $fillable = [
        'card_no',
        'status',
        'issued_at',
        'club_id',
        'card_type_id',
        'is_assigned'
    ];

    public static function statuses()
    {
        return ['pending', 'active', 'blocked', 'lost', 'damaged'];
    }

    public function memberMapping()
    {
        return $this->hasOne(MemberCardMapping::class, 'card_id');
    }
}
