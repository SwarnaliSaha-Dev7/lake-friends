<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class AddOn extends Model
{
    protected $fillable = [
        'club_id',
        'name',
        'price',
        'is_active'
    ];
}
